sudo cp -i -r lite_dreams /usr/share/plymouth/themes/
sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/lite_dreams/lite_dreams.plymouth 100
sudo update-alternatives --config default.plymouth
sudo update-initramfs -u