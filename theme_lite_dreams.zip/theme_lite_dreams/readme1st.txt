IMPORTANT : This Theme is for Ubuntu 16.04+ based distributions only. (Linux Lite 3.x, Linux Mint 18.x, etc.)

To install :
0. Uncompress the archive file to a folder... but you already did that since you are reading this. ;)
1. Open the theme_lite_dreams folder where install.sh is located.
2. Right click on this windows in the empty space and choose "Open a Terminal Windows here"
3. Type . install.sh (i.e. dot + install.sh) and press enter.
    The theme will copy to correct folder...
4. Install will ask you to choose the theme from a list, select the appropriate line number, press enter.
    You will see something like "update-initramfs: Generating /boot/initrd.img-4.4.x-xx-generic"
5. Wait a few moments and when the prompt returns, reboot your computer and be amazed at your new Boot Spash Screen. :)


To Uninstall :
1. Run install.sh again but choose another theme (i.e. not this one).
2. When the prompt returns, go to the following folder as an adminsitrator
/usr/share/plymouth/themes/
3. Delete the unwanted theme-name folder